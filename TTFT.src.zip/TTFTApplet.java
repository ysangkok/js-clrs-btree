/*    */ import java.applet.Applet;
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ public class TTFTApplet extends Applet
/*    */   implements Runnable
/*    */ {
/*    */   private GraphicalTTFT gt;
/*    */   private TTFTAppletControls controls;
/*    */   private Thread doer;
/*    */ 
/*    */   public void init()
/*    */   {
/* 18 */     this.gt = new GraphicalTTFT(this, new Font("Serif", 0, 10), Color.black, Color.white, Color.red, 2, getSize().width / 2);
/*    */ 
/* 21 */     setBackground(Color.lightGray);
/*    */ 
/* 24 */     this.controls = new TTFTAppletControls(this, this.gt);
/* 25 */     setLayout(new BorderLayout());
/* 26 */     add(this.controls, "South");
/*    */ 
/* 29 */     this.doer = new Thread(this);
/* 30 */     this.doer.start();
/*    */   }
/*    */ 
/*    */   public void resize() {
/* 34 */     this.gt.resize(getSize().width / 2);
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 38 */     remove(this.controls);
/* 39 */     this.doer = null;
/*    */   }
/*    */ 
/*    */   public void start() {
/* 43 */     this.controls.setEnabled(true);
/*    */   }
/*    */ 
/*    */   public void stop() {
/* 47 */     this.controls.setEnabled(false);
/*    */   }
/*    */ 
/*    */   public void run() {
/* 51 */     Thread localThread = Thread.currentThread();
/* 52 */     while (localThread == this.doer)
/*    */       try {
/* 54 */         synchronized (this.gt) {
/* 55 */           this.gt.wait();
/*    */         }
/* 57 */         this.gt.Perform();
/* 58 */         repaint();
/* 59 */         this.controls.setEnabled(true);
/*    */       } catch (InterruptedException localInterruptedException) {
/*    */       } catch (TTFTException localTTFTException) {
/* 62 */         this.gt.setInfo("Exception (see console): " + localTTFTException.getMessage());
/* 63 */         repaint();
/* 64 */         localTTFTException.printStackTrace();
/*    */       }
/*    */   }
/*    */ 
/*    */   public void paint(Graphics paramGraphics)
/*    */   {
/* 71 */     this.gt.Draw(paramGraphics);
/*    */   }
/*    */ 
/*    */   public String getAppletInfo()
/*    */   {
/* 76 */     return "Title: A Graphical 2-3-4 Tree\nAuthor: Rory McGuire, rlpm@unm.edu 2004";
/*    */   }
/*    */ 
/*    */   public static void main(String[] paramArrayOfString)
/*    */   {
/* 81 */     JFrame localJFrame = new JFrame("2-3-4 Tree");
/* 82 */     TTFTApplet localTTFTApplet = new TTFTApplet();
/* 83 */     localJFrame.setSize(800, 200);
/* 84 */     localTTFTApplet.setSize(800, 200);
/*    */ 
/* 86 */     localJFrame.getContentPane().add("Center", localTTFTApplet);
/*    */ 
/* 88 */     localJFrame.setDefaultCloseOperation(3);
/* 89 */     localTTFTApplet.init();
/* 90 */     localTTFTApplet.start();
/*    */ 
/* 92 */     localJFrame.show();
/*    */   }
/*    */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     TTFTApplet
 * JD-Core Version:    0.6.2
 */