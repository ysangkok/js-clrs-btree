/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class TTFT
/*     */ {
/*   8 */   private boolean splitdown = false;
/*     */ 
/*  10 */   private boolean findfirst = false;
/*     */   protected TTFT.Node root;
/*     */   private Integer depth;
/*     */ 
/*     */   public TTFT()
/*     */   {
/*  20 */     this.root = CreateNode();
/*     */   }
/*     */ 
/*     */   protected void sleepytime()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean Insert(int paramInt)
/*     */     throws TTFTException
/*     */   {
/*  36 */     if ((this.findfirst) && (Find(paramInt)))
/*  37 */       return false;
/*  38 */     if ((this.splitdown) && (this.root.numvals == 3)) {
/*  39 */       this.root.high = true;
/*  40 */       sleepytime();
/*  41 */       TTFT.Node localNode = CreateNode();
/*  42 */       localNode.children[0] = this.root;
/*  43 */       this.root.parent = localNode;
/*  44 */       this.root = localNode;
/*  45 */       localNode.children[0].Split();
/*     */     }
/*  47 */     boolean bool = this.root.Insert(paramInt);
/*  48 */     checkSanity();
/*  49 */     return bool;
/*     */   }
/*     */ 
/*     */   public boolean Find(int paramInt)
/*     */   {
/*  59 */     return this.root.Find(paramInt);
/*     */   }
/*     */ 
/*     */   public boolean Delete(int paramInt)
/*     */     throws TTFTException
/*     */   {
/*  69 */     if ((this.findfirst) && (!Find(paramInt))) {
/*  70 */       return false;
/*     */     }
/*  72 */     boolean bool = this.root.Delete(paramInt);
/*  73 */     checkSanity();
/*  74 */     return bool;
/*     */   }
/*     */ 
/*     */   private void checkSanity() throws TTFTException
/*     */   {
/*     */     try
/*     */     {
/*  81 */       this.depth = null;
/*  82 */       checkLinks();
/*     */     } catch (TTFTException localTTFTException) {
/*  84 */       this.root.Dump();
/*  85 */       throw localTTFTException;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkLinks()
/*     */     throws TTFTException
/*     */   {
/*  93 */     if (this.root.parent != null)
/*  94 */       throw new TTFTException("root parent should be null!");
/*  95 */     this.root.checkLinks(0);
/*     */   }
/*     */ 
/*     */   public boolean SplitOnTheWayDown()
/*     */   {
/* 104 */     return this.splitdown;
/*     */   }
/*     */ 
/*     */   public void SplitOnTheWayDown(boolean paramBoolean)
/*     */   {
/* 113 */     this.splitdown = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean FindFirst()
/*     */   {
/* 124 */     return this.findfirst;
/*     */   }
/*     */ 
/*     */   public void FindFirst(boolean paramBoolean)
/*     */   {
/* 133 */     this.findfirst = paramBoolean;
/*     */   }
/*     */ 
/*     */   public void Dump()
/*     */   {
/* 140 */     this.root.Dump();
/*     */   }
/*     */ 
/*     */   public void Reset()
/*     */   {
/* 147 */     this.root = CreateNode();
/*     */   }
/*     */ 
/*     */   protected TTFT.Node CreateNode()
/*     */   {
/* 158 */     return new TTFT.Node();
/*     */   }
/*     */ 
/*     */   protected class Node
/*     */   {
/*     */     protected int numvals;
/*     */     protected int[] vals;
/*     */     protected Node parent;
/*     */     protected Node[] children;
/* 178 */     protected boolean high = false;
/*     */ 
/*     */     public Node() {
/* 181 */       this.numvals = 0;
/* 182 */       this.vals = new int[3];
/* 183 */       this.parent = null;
/* 184 */       this.children = new Node[4];
/*     */     }
/*     */ 
/*     */     public boolean Insert(int paramInt)
/*     */       throws TTFTException
/*     */     {
/* 196 */       this.high = true;
/* 197 */       TTFT.this.sleepytime();
/*     */       try
/*     */       {
/*     */         boolean bool3;
/* 199 */         if (this.children[0] == null) {
/* 200 */           if (this.numvals == 3)
/*     */           {
/* 204 */             if ((this.vals[0] == paramInt) || (this.vals[1] == paramInt) || (this.vals[2] == paramInt))
/*     */             {
/* 206 */               this.high = false;
/* 207 */               return 0;
/*     */             }
/* 209 */             return Split().Insert(paramInt);
/*     */           }
/*     */ 
/* 212 */           for (int i = 0; i < this.numvals; i++) {
/* 213 */             if (this.vals[i] == paramInt) {
/* 214 */               this.high = false;
/* 215 */               return false;
/* 216 */             }if (paramInt < this.vals[i]) {
/* 217 */               for (int k = this.numvals; k > i; k--) {
/* 218 */                 this.vals[k] = this.vals[(k - 1)];
/*     */               }
/* 220 */               this.vals[i] = paramInt;
/* 221 */               this.numvals += 1;
/* 222 */               return true;
/*     */             }
/*     */           }
/* 225 */           this.vals[(this.numvals++)] = paramInt;
/* 226 */           return 1;
/*     */         }
/* 228 */         this.high = false;
/*     */ 
/* 232 */         for (int j = 0; j < this.numvals; j++) {
/* 233 */           if (paramInt == this.vals[j])
/* 234 */             return false;
/* 235 */           if (paramInt < this.vals[j]) {
/* 236 */             if ((TTFT.this.splitdown) && (this.children[j].numvals == 3)) {
/* 237 */               return this.children[j].Split().Insert(paramInt);
/*     */             }
/* 239 */             return this.children[j].Insert(paramInt);
/*     */           }
/*     */         }
/*     */         boolean bool1;
/* 242 */         if ((TTFT.this.splitdown) && (this.children[this.numvals].numvals == 3)) {
/* 243 */           return this.children[this.numvals].Split().Insert(paramInt);
/*     */         }
/* 245 */         return this.children[this.numvals].Insert(paramInt);
/*     */       }
/*     */       finally {
/* 248 */         if (this.high) {
/* 249 */           TTFT.this.sleepytime();
/* 250 */           this.high = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     private Node Split()
/*     */       throws TTFTException
/*     */     {
/* 262 */       if (this.numvals != 3) {
/* 263 */         throw new TTFTException("Tried to split node that doesn't have 3 values");
/*     */       }
/* 265 */       if (this.parent == null)
/*     */       {
/* 267 */         localNode = TTFT.this.CreateNode();
/* 268 */         localNode.children[0] = this;
/* 269 */         this.parent = localNode;
/* 270 */         TTFT.this.root = localNode;
/*     */       }
/* 272 */       this.parent.high = true;
/* 273 */       this.high = true;
/* 274 */       TTFT.this.sleepytime();
/* 275 */       if (this.parent.numvals == 3) {
/* 276 */         this.parent.Split();
/* 277 */         TTFT.this.sleepytime();
/*     */       }
/* 279 */       this.parent.high = false;
/* 280 */       this.high = false;
/*     */ 
/* 282 */       Node localNode = TTFT.this.CreateNode();
/* 283 */       localNode.numvals = 1;
/* 284 */       localNode.vals = new int[3];
/* 285 */       localNode.vals[0] = this.vals[2];
/* 286 */       localNode.parent = this.parent;
/* 287 */       localNode.children = new Node[4];
/* 288 */       if (this.children[2] != null)
/*     */       {
/* 290 */         localNode.children[0] = this.children[2];
/* 291 */         localNode.children[0].parent = localNode;
/* 292 */         localNode.children[1] = this.children[3];
/* 293 */         localNode.children[1].parent = localNode;
/*     */       }
/* 295 */       this.numvals = 1;
/*     */        tmp229_228 = null; this.children[3] = tmp229_228; this.children[2] = tmp229_228;
/* 297 */       this.parent.Push(this.vals[1], localNode);
/* 298 */       return this.parent;
/*     */     }
/*     */ 
/*     */     private void Push(int paramInt, Node paramNode)
/*     */       throws TTFTException
/*     */     {
/* 310 */       int i = this.numvals;
/* 311 */       while ((i != 0) && (paramInt < this.vals[(i - 1)])) {
/* 312 */         this.vals[i] = this.vals[(i - 1)];
/* 313 */         this.children[(i + 1)] = this.children[i];
/* 314 */         i--;
/*     */       }
/* 316 */       this.numvals += 1;
/* 317 */       this.vals[i] = paramInt;
/* 318 */       this.children[(i + 1)] = paramNode;
/* 319 */       paramNode.parent = this;
/*     */     }
/*     */ 
/*     */     public void Dump()
/*     */     {
/* 327 */       System.out.println(this);
/* 328 */       System.out.println("Parent: " + this.parent);
/* 329 */       System.out.print("Values(" + this.numvals + "): ");
/* 330 */       for (int i = 0; i < this.numvals; i++)
/* 331 */         System.out.print(this.vals[i] + " ");
/* 332 */       System.out.println();
/* 333 */       System.out.println("Children:");
/* 334 */       for (i = 0; i < 4; i++)
/* 335 */         System.out.println(this.children[i]);
/* 336 */       System.out.println();
/* 337 */       if (this.children[0] != null)
/* 338 */         this.children[0].Dump();
/* 339 */       if (this.children[1] != null)
/* 340 */         this.children[1].Dump();
/* 341 */       if (this.children[2] != null)
/* 342 */         this.children[2].Dump();
/* 343 */       if (this.children[3] != null)
/* 344 */         this.children[3].Dump();
/*     */     }
/*     */ 
/*     */     public boolean Find(int paramInt)
/*     */     {
/* 354 */       this.high = true;
/* 355 */       TTFT.this.sleepytime();
/* 356 */       this.high = false;
/*     */       try
/*     */       {
/* 359 */         for (int i = 0; i < this.numvals; i++)
/*     */         {
/*     */           boolean bool2;
/* 360 */           if (paramInt == this.vals[i])
/* 361 */             return true;
/* 362 */           if (paramInt < this.vals[i]) {
/* 363 */             if (this.children[i] == null) {
/* 364 */               return false;
/*     */             }
/* 366 */             return this.children[i].Find(paramInt);
/*     */           }
/*     */         }
/* 369 */         if (this.children[this.numvals] == null) {
/* 370 */           return 0;
/*     */         }
/* 372 */         return this.children[this.numvals].Find(paramInt);
/*     */       } finally {
/* 374 */         this.high = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     private void Merge(int paramInt)
/*     */       throws TTFTException
/*     */     {
/* 388 */       if ((this.numvals == 1) && (this != TTFT.this.root)) {
/* 389 */         throw new TTFTException("Not enough vals in this node!");
/*     */       }
/*     */ 
/* 392 */       Node localNode1 = this.children[paramInt];
/* 393 */       Node localNode2 = this.children[(paramInt + 1)];
/*     */ 
/* 395 */       if (localNode1.numvals != 1)
/* 396 */         throw new TTFTException("Too many vals in lchild!");
/* 397 */       if (localNode2.numvals != 1) {
/* 398 */         throw new TTFTException("Too many vals in rchild!");
/*     */       }
/* 400 */       localNode1.high = true;
/* 401 */       localNode2.high = true;
/* 402 */       TTFT.this.sleepytime();
/*     */ 
/* 405 */       localNode1.vals[1] = this.vals[paramInt];
/* 406 */       localNode1.vals[2] = localNode2.vals[0];
/* 407 */       localNode1.numvals = 3;
/*     */ 
/* 410 */       for (int i = paramInt; i < this.numvals - 1; i++) {
/* 411 */         this.vals[i] = this.vals[(i + 1)];
/* 412 */         this.children[(i + 1)] = this.children[(i + 2)];
/*     */       }
/* 414 */       this.children[this.numvals] = null;
/* 415 */       this.numvals -= 1;
/*     */ 
/* 418 */       if (localNode1.children[0] != null)
/*     */       {
/* 420 */         localNode1.children[2] = localNode2.children[0];
/* 421 */         localNode1.children[2].parent = localNode1;
/* 422 */         localNode1.children[3] = localNode2.children[1];
/* 423 */         localNode1.children[3].parent = localNode1;
/*     */       }
/*     */ 
/* 426 */       TTFT.this.sleepytime();
/* 427 */       localNode1.high = false;
/* 428 */       if ((this == TTFT.this.root) && (this.numvals == 0)) {
/* 429 */         TTFT.this.root = localNode1;
/* 430 */         TTFT.this.root.parent = null;
/* 431 */         TTFT.this.root.high = true;
/* 432 */         TTFT.this.sleepytime();
/*     */       }
/*     */     }
/*     */ 
/*     */     private Node MaintainInvariant(int paramInt, Node paramNode1, Node paramNode2, Node paramNode3)
/*     */       throws TTFTException
/*     */     {
/* 448 */       if (paramNode2.numvals != 1) {
/* 449 */         return paramNode2;
/*     */       }
/* 451 */       paramNode2.high = true;
/* 452 */       int i = 1;
/* 453 */       if ((paramNode1 != null) && (paramNode1.numvals > 1))
/*     */       {
/* 455 */         i = 1;
/* 456 */         paramNode1.high = true;
/* 457 */         paramInt--;
/* 458 */       } else if ((paramNode3 != null) && (paramNode3.numvals > 1))
/*     */       {
/* 460 */         i = 0;
/* 461 */         paramNode3.high = true; } else {
/* 462 */         if (paramNode1 != null) {
/* 463 */           Merge(paramInt - 1);
/* 464 */           return paramNode1;
/* 465 */         }if (paramNode3 != null) {
/* 466 */           Merge(paramInt);
/* 467 */           return paramNode2;
/*     */         }
/* 469 */         throw new TTFTException("Can't maintain invariant!");
/*     */       }
/*     */ 
/* 472 */       TTFT.this.sleepytime();
/*     */ 
/* 474 */       if (i != 0)
/*     */       {
/* 476 */         paramNode2.vals[1] = paramNode2.vals[0];
/* 477 */         paramNode2.vals[0] = this.vals[paramInt];
/* 478 */         this.vals[paramInt] = paramNode1.vals[(paramNode1.numvals - 1)];
/*     */ 
/* 481 */         if (paramNode2.children[0] != null)
/*     */         {
/* 483 */           paramNode2.children[2] = paramNode2.children[1];
/* 484 */           paramNode2.children[1] = paramNode2.children[0];
/* 485 */           paramNode2.children[0] = paramNode1.children[paramNode1.numvals];
/* 486 */           paramNode1.children[paramNode1.numvals] = null;
/* 487 */           paramNode2.children[0].parent = paramNode2;
/*     */         }
/*     */ 
/* 491 */         paramNode1.numvals -= 1;
/* 492 */         paramNode2.numvals = 2;
/*     */       }
/*     */       else {
/* 495 */         paramNode2.vals[1] = this.vals[paramInt];
/* 496 */         this.vals[paramInt] = paramNode3.vals[0];
/*     */ 
/* 499 */         if (paramNode2.children[0] != null)
/*     */         {
/* 501 */           paramNode2.children[2] = paramNode3.children[0];
/* 502 */           paramNode2.children[2].parent = paramNode2;
/*     */         }
/*     */ 
/* 506 */         for (int j = 0; j < paramNode3.numvals - 1; j++) {
/* 507 */           paramNode3.vals[j] = paramNode3.vals[(j + 1)];
/* 508 */           paramNode3.children[j] = paramNode3.children[(j + 1)];
/*     */         }
/* 510 */         paramNode3.children[(paramNode3.numvals - 1)] = paramNode3.children[paramNode3.numvals];
/* 511 */         paramNode3.children[paramNode3.numvals] = null;
/* 512 */         paramNode3.numvals -= 1;
/*     */ 
/* 515 */         paramNode2.numvals = 2;
/*     */       }
/* 517 */       TTFT.this.sleepytime();
/* 518 */       if (paramNode1 != null) paramNode1.high = false;
/* 519 */       if (paramNode3 != null) paramNode3.high = false;
/* 520 */       paramNode2.high = false;
/* 521 */       return paramNode2;
/*     */     }
/*     */ 
/*     */     public int DeleteMax()
/*     */       throws TTFTException
/*     */     {
/* 531 */       if (this.numvals == 1) {
/* 532 */         throw new TTFTException("not enough vals!");
/*     */       }
/* 534 */       this.high = true;
/* 535 */       TTFT.this.sleepytime();
/*     */       try
/*     */       {
/*     */         int j;
/* 537 */         if (this.children[0] != null)
/*     */         {
/* 539 */           Node localNode1 = this.children[this.numvals];
/* 540 */           localNode1.high = true;
/* 541 */           TTFT.this.sleepytime();
/* 542 */           if (localNode1.numvals == 1) {
/* 543 */             Node localNode2 = this.children[(this.numvals - 1)];
/* 544 */             localNode2.high = true;
/* 545 */             TTFT.this.sleepytime();
/* 546 */             if (localNode2.numvals == 1)
/* 547 */               Merge(this.numvals - 1);
/*     */             else {
/* 549 */               MaintainInvariant(this.numvals, this.children[(this.numvals - 1)], this.children[this.numvals], null);
/*     */             }
/*     */ 
/* 552 */             return this.children[this.numvals].DeleteMax();
/*     */           }
/* 554 */           return localNode1.DeleteMax();
/*     */         }
/*     */ 
/* 558 */         int i = this.vals[(--this.numvals)];
/* 559 */         TTFT.this.sleepytime();
/* 560 */         return i;
/*     */       }
/*     */       finally {
/* 563 */         this.high = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     public int DeleteMin()
/*     */       throws TTFTException
/*     */     {
/* 574 */       if (this.numvals == 1) {
/* 575 */         throw new TTFTException("not enough vals!");
/*     */       }
/* 577 */       this.high = true;
/* 578 */       TTFT.this.sleepytime();
/*     */       try {
/* 580 */         if (this.children[0] != null)
/*     */         {
/* 582 */           Node localNode1 = this.children[0];
/* 583 */           localNode1.high = true;
/* 584 */           TTFT.this.sleepytime();
/* 585 */           if (localNode1.numvals == 1) {
/* 586 */             Node localNode2 = this.children[1];
/* 587 */             localNode2.high = true;
/* 588 */             TTFT.this.sleepytime();
/* 589 */             if (localNode2.numvals == 1)
/* 590 */               Merge(0);
/*     */             else {
/* 592 */               MaintainInvariant(0, null, this.children[0], this.children[1]);
/*     */             }
/* 594 */             return this.children[0].DeleteMin();
/*     */           }
/* 596 */           return localNode1.DeleteMin();
/*     */         }
/*     */ 
/* 600 */         int i = this.vals[0];
/* 601 */         for (int j = 0; j < this.numvals - 1; j++) {
/* 602 */           this.vals[j] = this.vals[(j + 1)];
/*     */         }
/* 604 */         this.numvals -= 1;
/* 605 */         TTFT.this.sleepytime();
/* 606 */         return i;
/*     */       }
/*     */       finally {
/* 609 */         this.high = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean Delete(int paramInt) throws TTFTException
/*     */     {
/* 615 */       if (this.numvals == 0) {
/* 616 */         return false;
/*     */       }
/* 618 */       this.high = true;
/* 619 */       TTFT.this.sleepytime();
/* 620 */       boolean bool1 = false;
/* 621 */       int i = 0;
/* 622 */       Object localObject1 = null;
/* 623 */       Node localNode1 = null;
/* 624 */       Node localNode2 = null;
/*     */       try
/*     */       {
/* 628 */         for (; i < this.numvals; i++) {
/* 629 */           localObject1 = localNode1;
/* 630 */           localNode1 = this.children[i];
/* 631 */           localNode2 = this.children[(i + 1)];
/* 632 */           if (paramInt == this.vals[i])
/* 633 */             bool1 = true;
/*     */           else {
/* 635 */             if (paramInt < this.vals[i])
/*     */               break;
/*     */           }
/*     */         }
/* 639 */         if (i == this.numvals) {
/* 640 */           localObject1 = this.children[(i - 1)];
/* 641 */           localNode1 = this.children[i];
/* 642 */           localNode2 = null;
/*     */         }
/*     */         boolean bool2;
/* 644 */         if (this.children[0] == null) {
/* 645 */           if (bool1) {
/* 646 */             for (; i < this.numvals - 1; i++) {
/* 647 */               this.vals[i] = this.vals[(i + 1)];
/*     */             }
/* 649 */             this.numvals -= 1;
/* 650 */             TTFT.this.sleepytime();
/*     */           }
/* 652 */           return bool1;
/* 653 */         }if (bool1) {
/* 654 */           if (localNode1.numvals > 1) {
/* 655 */             this.vals[i] = localNode1.DeleteMax();
/* 656 */             TTFT.this.sleepytime();
/* 657 */             return true;
/* 658 */           }if (localNode2.numvals > 1) {
/* 659 */             this.vals[i] = localNode2.DeleteMin();
/* 660 */             TTFT.this.sleepytime();
/* 661 */             return true;
/*     */           }
/* 663 */           Merge(i);
/* 664 */           this.high = false;
/* 665 */           return localNode1.Delete(paramInt);
/*     */         }
/*     */ 
/* 668 */         Node localNode3 = MaintainInvariant(i, (Node)localObject1, localNode1, localNode2);
/*     */ 
/* 671 */         this.high = false;
/* 672 */         return localNode3.Delete(paramInt);
/*     */       }
/*     */       finally {
/* 675 */         this.high = false;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void checkLinks(int paramInt)
/*     */       throws TTFTException
/*     */     {
/* 685 */       for (int i = 0; i <= this.numvals; i++) {
/* 686 */         if (this.children[i] != null) {
/* 687 */           if (this.children[i].parent != this)
/* 688 */             throw new TTFTException(this + " broken link!");
/* 689 */           this.children[i].checkLinks(paramInt + 1);
/* 690 */         } else if (TTFT.this.depth == null) {
/* 691 */           if (i != 0)
/* 692 */             throw new TTFTException(this + " first child problem!");
/* 693 */           TTFT.this.depth = new Integer(paramInt);
/* 694 */         } else if (TTFT.this.depth.intValue() != paramInt) {
/* 695 */           throw new TTFTException(this + " not same depth as first leaf!");
/*     */         }
/*     */       }
/* 698 */       for (i = this.numvals + 1; i < 4; i++)
/* 699 */         if (this.children[i] != null)
/* 700 */           throw new TTFTException(this + " child should be null!");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     TTFT
 * JD-Core Version:    0.6.2
 */