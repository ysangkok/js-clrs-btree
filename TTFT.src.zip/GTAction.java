/*     */ class GTAction
/*     */ {
/* 295 */   public static int INSERT = 0;
/* 296 */   public static int FIND = 1;
/* 297 */   public static int DELETE = 2;
/*     */   public int action;
/*     */   public int data;
/*     */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     GTAction
 * JD-Core Version:    0.6.2
 */