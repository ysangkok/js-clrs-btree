/*   */ class TTFTException extends Exception
/*   */ {
/*   */   TTFTException(String paramString)
/*   */   {
/* 4 */     super(paramString);
/*   */   }
/*   */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     TTFTException
 * JD-Core Version:    0.6.2
 */