/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ 
/*     */ public class GraphicalTTFT extends TTFT
/*     */ {
/*     */   private TTFTApplet ttfta;
/*     */   private Font font;
/*     */   private FontMetrics metrics;
/*     */   private Color nodeOlColor;
/*     */   private Color nodeBgColor;
/*     */   private Color nodeHighColor;
/*     */   private int nodeBorder;
/*     */   private int nodeHeight;
/*     */   private Point startPt;
/*     */   private int lineY;
/*     */   private String info;
/*     */   private Point infopt;
/*     */   private int sleepy;
/*     */   private GTAction gta;
/*     */ 
/*     */   public GraphicalTTFT(TTFTApplet a, Font fnt, Color nodeOl, Color nodeBg, Color nodeHigh, int border, int startx)
/*     */   {
/*  27 */     this.ttfta = a;
/*  28 */     this.font = fnt;
/*  29 */     this.metrics = a.getFontMetrics(this.font);
/*  30 */     this.nodeOlColor = nodeOl;
/*  31 */     this.nodeBgColor = nodeBg;
/*  32 */     this.nodeHighColor = nodeHigh;
/*  33 */     this.nodeBorder = border;
/*  34 */     this.nodeHeight = (this.metrics.getHeight() + this.nodeBorder * 2);
/*  35 */     this.startPt = new Point(startx, this.nodeHeight / 2 + this.nodeBorder);
/*  36 */     this.lineY = (this.nodeHeight + this.nodeBorder * 2);
/*  37 */     this.info = new String();
/*  38 */     this.infopt = new Point(this.nodeBorder, this.metrics.getAscent());
/*     */ 
/*  41 */     this.sleepy = 1000;
/*     */   }
/*     */ 
/*     */   public void resize(int startx) {
/*  45 */     this.startPt.x = startx;
/*     */   }
/*     */ 
/*     */   public synchronized void slowest()
/*     */   {
/*  51 */     this.sleepy = 1900;
/*  52 */     speedinfo();
/*     */   }
/*     */ 
/*     */   public synchronized void fastest() {
/*  56 */     this.sleepy = 0;
/*  57 */     speedinfo();
/*     */   }
/*     */ 
/*     */   public synchronized void slower() {
/*  61 */     if (this.sleepy < 1900)
/*  62 */       this.sleepy += 100;
/*  63 */     speedinfo();
/*     */   }
/*     */ 
/*     */   public synchronized void faster() {
/*  67 */     if (this.sleepy > 0)
/*  68 */       this.sleepy -= 100;
/*  69 */     speedinfo();
/*     */   }
/*     */ 
/*     */   public synchronized void Reset() {
/*  73 */     super.Reset();
/*  74 */     this.info = "Tree reset!";
/*     */   }
/*     */ 
/*     */   public synchronized boolean Insert(int what) throws TTFTException {
/*  78 */     boolean ret = true;
/*  79 */     boolean ff = FindFirst();
/*  80 */     FindFirst(false);
/*  81 */     if (ff) {
/*  82 */       this.info = ("Finding first: " + what);
/*  83 */       if (super.Find(what)) {
/*  84 */         ret = false;
/*     */       }
/*     */     }
/*  87 */     if (ret) {
/*  88 */       this.info = ("Inserting: " + what);
/*  89 */       ret = super.Insert(what);
/*  90 */       if (ret) this.info = ("Inserted: " + what);
/*     */     }
/*  92 */     if (!ret)
/*  93 */       this.info = ("Value: " + what + " already in tree!");
/*  94 */     FindFirst(ff);
/*  95 */     return ret;
/*     */   }
/*     */ 
/*     */   public synchronized int getRandom(boolean intree) {
/*  99 */     int ret = (int)(Math.random() * 100.0D);
/* 100 */     int prevsleepy = this.sleepy;
/* 101 */     this.sleepy = 0;
/* 102 */     for (int i = 0; 
/* 103 */       (i < 100) && 
/* 104 */       (intree != super.Find(ret)); i++)
/*     */     {
/* 105 */       ret = (ret + 13) % 100;
/*     */     }
/* 107 */     if (i == 100) ret = -1;
/* 108 */     this.sleepy = prevsleepy;
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */   public synchronized boolean Find(int what) {
/* 113 */     this.info = ("Finding: " + what);
/* 114 */     boolean ret = super.Find(what);
/* 115 */     String after = "Value: " + what + " ";
/* 116 */     if (!ret) after = after + "not ";
/* 117 */     after = after + "found!";
/* 118 */     this.info = after;
/* 119 */     return ret;
/*     */   }
/*     */ 
/*     */   public synchronized boolean Delete(int what) throws TTFTException {
/* 123 */     boolean ret = true;
/* 124 */     boolean ff = FindFirst();
/* 125 */     FindFirst(false);
/* 126 */     if (ff) {
/* 127 */       this.info = ("Finding first: " + what);
/* 128 */       if (!super.Find(what)) {
/* 129 */         ret = false;
/*     */       }
/*     */     }
/* 132 */     if (ret) {
/* 133 */       this.info = ("Deleting: " + what);
/* 134 */       ret = super.Delete(what);
/* 135 */       if (ret) this.info = ("Deleted: " + what);
/*     */     }
/* 137 */     if (!ret)
/* 138 */       this.info = ("Value: " + what + " not in tree!");
/* 139 */     FindFirst(ff);
/* 140 */     return ret;
/*     */   }
/*     */ 
/*     */   private void speedinfo()
/*     */   {
/* 145 */     this.info = ("Speed: " + (2000 - this.sleepy) / 20 + "%");
/*     */   }
/*     */ 
/*     */   protected synchronized void sleepytime()
/*     */   {
/* 150 */     if (this.sleepy != 0) {
/* 151 */       this.ttfta.repaint();
/*     */       try {
/* 153 */         wait(this.sleepy);
/*     */       }
/*     */       catch (InterruptedException e) {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void setInfo(String s) {
/* 161 */     this.info = s;
/*     */   }
/*     */ 
/*     */   public synchronized void Draw(Graphics g)
/*     */   {
/* 166 */     ((GraphicalTTFT.GNode)this.root).drawNode(this.startPt, g);
/* 167 */     g.drawString(this.info, this.infopt.x, this.infopt.y);
/*     */   }
/*     */ 
/*     */   public synchronized void Request(GTAction act)
/*     */   {
/* 172 */     this.gta = act;
/* 173 */     notify();
/*     */   }
/*     */ 
/*     */   public synchronized void Perform() throws TTFTException
/*     */   {
/* 178 */     if (this.gta.action == GTAction.INSERT)
/* 179 */       Insert(this.gta.data);
/* 180 */     else if (this.gta.action == GTAction.FIND)
/* 181 */       Find(this.gta.data);
/* 182 */     else if (this.gta.action == GTAction.DELETE)
/* 183 */       Delete(this.gta.data);
/*     */     else
/* 185 */       throw new TTFTException("do not know action: " + this.gta.action);
/* 186 */     this.gta = null;
/*     */   }
/*     */ 
/*     */   public synchronized void SplitOnTheWayDown(boolean torf)
/*     */   {
/* 192 */     super.SplitOnTheWayDown(torf);
/*     */   }
/*     */   public synchronized void FindFirst(boolean torf) {
/* 195 */     super.FindFirst(torf);
/*     */   }
/*     */ 
/*     */   protected TTFT.Node CreateNode()
/*     */   {
/* 200 */     return new GraphicalTTFT.GNode(null);
/*     */   }
/*     */ 
/*     */   private class GNode extends TTFT.Node
/*     */   {
/*     */     private GNode() {
/* 206 */       super();
/*     */     }
/*     */     private int getWidth(Graphics g) {
/* 209 */       if (this.children[0] != null) {
/* 210 */         int width = GraphicalTTFT.this.nodeBorder;
/* 211 */         for (int i = 0; i <= this.numvals; i++)
/* 212 */           width += ((GNode)this.children[i]).getWidth(g) + GraphicalTTFT.this.nodeBorder;
/* 213 */         return width;
/*     */       }
/* 215 */       return myWidth();
/*     */     }
/*     */ 
/*     */     private int myWidth()
/*     */     {
/* 221 */       int width = GraphicalTTFT.this.nodeBorder;
/* 222 */       for (int i = 0; i < this.numvals; i++) {
/* 223 */         width += GraphicalTTFT.this.metrics.stringWidth(Integer.toString(this.vals[i]));
/*     */       }
/* 225 */       width += GraphicalTTFT.this.nodeBorder * this.numvals;
/* 226 */       return width;
/*     */     }
/*     */ 
/*     */     private void drawNode(Point center, Graphics g) {
/* 230 */       Point where = new Point(center);
/* 231 */       g.setFont(GraphicalTTFT.this.font);
/* 232 */       int width = myWidth();
/* 233 */       where.x -= width / 2;
/* 234 */       where.y -= GraphicalTTFT.this.nodeHeight / 2;
/* 235 */       if (this.high)
/* 236 */         g.setColor(GraphicalTTFT.this.nodeHighColor);
/*     */       else
/* 238 */         g.setColor(GraphicalTTFT.this.nodeBgColor);
/* 239 */       if (this.numvals == 0)
/* 240 */         width += 2 * GraphicalTTFT.this.nodeBorder;
/* 241 */       g.fillRoundRect(where.x, where.y, width + 1, GraphicalTTFT.this.nodeHeight + 1, 5, 5);
/* 242 */       g.setColor(GraphicalTTFT.this.nodeOlColor);
/* 243 */       g.drawRoundRect(where.x, where.y, width, GraphicalTTFT.this.nodeHeight, 5, 5);
/*     */ 
/* 246 */       where.y += GraphicalTTFT.this.nodeBorder + GraphicalTTFT.this.metrics.getAscent();
/* 247 */       where.x += GraphicalTTFT.this.nodeBorder + 1;
/*     */ 
/* 249 */       String[] valss = new String[this.numvals];
/* 250 */       int[] valsw = new int[this.numvals];
/*     */ 
/* 252 */       for (int i = 0; i < this.numvals; i++) {
/* 253 */         valss[i] = Integer.toString(this.vals[i]);
/* 254 */         g.drawString(valss[i], where.x, where.y);
/* 255 */         valsw[i] = (GraphicalTTFT.this.nodeBorder + GraphicalTTFT.this.metrics.stringWidth(valss[i]));
/* 256 */         where.x += valsw[i];
/*     */       }
/*     */ 
/* 259 */       if (this.children[0] != null) {
/* 260 */         int[] cw = new int[this.numvals + 1];
/* 261 */         int tw = 0;
/* 262 */         for (int i = 0; i <= this.numvals; i++) {
/* 263 */           cw[i] = ((GNode)this.children[i]).getWidth(g);
/* 264 */           tw += cw[i];
/*     */         }
/* 266 */         Point cc = new Point(center.x - tw / 2, center.y + GraphicalTTFT.this.lineY);
/*     */ 
/* 268 */         Point st = new Point(center.x - myWidth() / 2 + GraphicalTTFT.this.nodeBorder / 2, center.y + GraphicalTTFT.this.nodeHeight / 2);
/*     */ 
/* 271 */         for (int i = 0; 
/* 272 */           i < this.numvals; i++) {
/* 273 */           cc.x += cw[i] / 2;
/* 274 */           g.drawLine(st.x, st.y, cc.x, cc.y - GraphicalTTFT.this.nodeHeight / 2);
/* 275 */           ((GNode)this.children[i]).drawNode(cc, g);
/* 276 */           cc.x += cw[i] / 2;
/* 277 */           cc.x += GraphicalTTFT.this.nodeBorder;
/* 278 */           st.x += valsw[i] + GraphicalTTFT.this.nodeBorder / 2;
/*     */         }
/* 280 */         cc.x += cw[i] / 2;
/* 281 */         if (this.numvals == 0) {
/* 282 */           st.x = center.x;
/*     */         } else {
/* 284 */           st.x -= 1;
/* 285 */           st.y -= 1;
/*     */         }
/* 287 */         g.drawLine(st.x, st.y, cc.x, cc.y - GraphicalTTFT.this.nodeHeight / 2);
/* 288 */         ((GNode)this.children[i]).drawNode(cc, g);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     GraphicalTTFT
 * JD-Core Version:    0.6.2
 */