/*     */ import java.awt.Button;
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Panel;
/*     */ import java.awt.TextField;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ class TTFTAppletControls extends Panel
/*     */   implements ActionListener, ItemListener
/*     */ {
/*     */   TTFTApplet a;
/*     */   GraphicalTTFT t;
/*     */   TextField in;
/*     */   Checkbox sotwd;
/*     */   Checkbox ff;
/*     */ 
/*     */   public TTFTAppletControls(TTFTApplet paramTTFTApplet, GraphicalTTFT paramGraphicalTTFT)
/*     */   {
/* 105 */     this.a = paramTTFTApplet;
/* 106 */     this.t = paramGraphicalTTFT;
/*     */ 
/* 108 */     Button localButton = null;
/* 109 */     localButton = new Button("Fastest");
/* 110 */     localButton.addActionListener(this);
/* 111 */     add(localButton);
/* 112 */     localButton = new Button("Faster");
/* 113 */     localButton.addActionListener(this);
/* 114 */     add(localButton);
/* 115 */     localButton = new Button("Slower");
/* 116 */     localButton.addActionListener(this);
/* 117 */     add(localButton);
/* 118 */     localButton = new Button("Slowest");
/* 119 */     localButton.addActionListener(this);
/* 120 */     add(localButton);
/* 121 */     add(this.in = new TextField("", 4));
/* 122 */     localButton = new Button("Insert");
/* 123 */     localButton.addActionListener(this);
/* 124 */     add(localButton);
/* 125 */     localButton = new Button("Find");
/* 126 */     localButton.addActionListener(this);
/* 127 */     add(localButton);
/* 128 */     localButton = new Button("Delete");
/* 129 */     localButton.addActionListener(this);
/* 130 */     add(localButton);
/* 131 */     localButton = new Button("Reset");
/* 132 */     localButton.addActionListener(this);
/* 133 */     add(localButton);
/* 134 */     add(this.sotwd = new Checkbox("Split on the way down"));
/* 135 */     this.sotwd.addItemListener(this);
/* 136 */     add(this.ff = new Checkbox("Find first"));
/* 137 */     this.ff.addItemListener(this);
/*     */   }
/*     */ 
/*     */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 141 */     String str1 = paramActionEvent.getActionCommand();
/* 142 */     String str2 = this.in.getText().trim();
/*     */ 
/* 144 */     if (str1.equals("Reset")) {
/* 145 */       this.t.Reset();
/* 146 */     } else if (str1.equals("Slowest")) {
/* 147 */       this.t.slowest();
/* 148 */     } else if (str1.equals("Fastest")) {
/* 149 */       this.t.fastest();
/* 150 */     } else if (str1.equals("Slower")) {
/* 151 */       this.t.slower();
/* 152 */     } else if (str1.equals("Faster")) {
/* 153 */       this.t.faster();
/*     */     } else {
/* 155 */       GTAction localGTAction = new GTAction();
/* 156 */       if (str2.equals(""))
/* 157 */         localGTAction.data = ((int)(Math.random() * 100.0D));
/*     */       else {
/*     */         try {
/* 160 */           localGTAction.data = Integer.parseInt(str2);
/* 161 */           if ((localGTAction.data < 0) || (localGTAction.data > 99))
/* 162 */             throw new NumberFormatException();
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException) {
/* 165 */           this.t.setInfo("Bad Input: " + str2);
/* 166 */           break label307;
/*     */         }
/*     */       }
/* 169 */       if (str1.equals("Insert")) {
/* 170 */         localGTAction.action = GTAction.INSERT;
/* 171 */       } else if (str1.equals("Find")) {
/* 172 */         localGTAction.action = GTAction.FIND;
/* 173 */       } else if (str1.equals("Delete")) {
/* 174 */         localGTAction.action = GTAction.DELETE;
/*     */       } else {
/* 176 */         this.t.setInfo("Unknown action!!!!");
/* 177 */         this.a.repaint();
/* 178 */         break label307;
/*     */       }
/* 180 */       setEnabled(false);
/* 181 */       this.t.Request(localGTAction);
/*     */     }
/*     */ 
/* 184 */     label307: this.a.repaint();
/*     */   }
/*     */ 
/*     */   public void itemStateChanged(ItemEvent paramItemEvent) {
/* 188 */     Object localObject = paramItemEvent.getSource();
/* 189 */     boolean bool = paramItemEvent.getStateChange() == 1;
/* 190 */     if (localObject == this.sotwd) this.t.SplitOnTheWayDown(bool);
/* 191 */     else if (localObject == this.ff) this.t.FindFirst(bool); else
/* 192 */       System.out.println("Some random crap happened!");
/*     */   }
/*     */ }

/* Location:           C:\Users\Janus\Downloads\btree\TTFT.jar
 * Qualified Name:     TTFTAppletControls
 * JD-Core Version:    0.6.2
 */